import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class Mailmanager {
	public static boolean sent(String Tomail,String subject,String Body) throws IOException {
		Properties props = new Properties();
		
		FileReader read=new FileReader("C:/Windows/Temp/mail.igx");
		props.load(read);
		props.put("mail.smtp.host", props.getProperty("Host"));
		props.put("mail.smtp.socketFactory.port", props.getProperty("Port"));
		props.put("mail.smtp.socketFactory.class",
				"javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", props.getProperty("Port"));
		
		/* reading data 
		 System.out.println(props.getProperty("Username"));
		System.out.println(props.getProperty("Password"));
		System.out.println(props.getProperty("Port"));
		System.out.println(props.getProperty("Host"));
		System.out.println(Tomail);
		System.out.println(subject);
		System.out.println(Body);*/
		
		
		Session session = Session.getDefaultInstance(props,
			new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(props.getProperty("Username"),props.getProperty("Password"));//get email ,pass
				}
			});

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(props.getProperty("Username")));//geting email to txt
			message.setRecipients(Message.RecipientType.TO,
					InternetAddress.parse(Tomail));
			message.setSubject(subject);
			message.setText(Body);

			Transport.send(message);

			
			return true;

		} catch (MessagingException e) {
			
			return false;
			//throw new RuntimeException(e);
			
			
		}
		
	}
}