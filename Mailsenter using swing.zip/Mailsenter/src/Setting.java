import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class Setting extends JDialog {

	private static final long serialVersionUID = 1;
	private final JPanel contentPanel = new JPanel();
	private JTextField textFieldMailId;
	private JTextField textFieldPassword;
	private JTextField textFieldHost;
	private JTextField textFieldPort;

	public Setting() throws IOException {
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(Setting.class.getResource("/com/sun/java/swing/plaf/windows/icons/Computer.gif")));
		setTitle("Setting");

		Properties props = new Properties();
		File file = new File("C:/Windows/Temp/mail.igx");

		FileReader read = new FileReader(file);
		props.load(read);

		setBounds(100, 100, 397, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblYourMailId = new JLabel("your mail id");
			lblYourMailId.setBounds(23, 53, 84, 23);
			contentPanel.add(lblYourMailId);
		}
		{
			JLabel lblPassword = new JLabel("Password");
			lblPassword.setBounds(23, 87, 79, 23);
			contentPanel.add(lblPassword);
		}
		{
			textFieldMailId = new JTextField();
			textFieldMailId.setBounds(121, 54, 208, 23);
			contentPanel.add(textFieldMailId);
			textFieldMailId.setColumns(10);
		}
		{
			textFieldPassword = new JTextField();
			textFieldPassword.setBounds(121, 88, 208, 20);
			contentPanel.add(textFieldPassword);
			textFieldPassword.setColumns(10);
		}
		{
			JButton btnSave = new JButton("save");
			btnSave.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					String toMailId = textFieldMailId.getText();
					String password = textFieldPassword.getText();
					String host = textFieldHost.getText();
					String port = textFieldPort.getText();

					props.setProperty("Username", toMailId);
					props.setProperty("Password", password);
					props.setProperty("Host", host);
					props.setProperty("Port", port);

					try {
						props.store(new FileWriter(file), "");

					} catch (IOException e1) {

						e1.printStackTrace();
					}

					Mailwindow test = new Mailwindow();
					dispose();
					test.setVisible(true);
				}
			});
			btnSave.setBounds(83, 204, 89, 23);
			contentPanel.add(btnSave);
		}
		{
			JButton btnCancle = new JButton("cancel");
			btnCancle.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnCancle.setBounds(250, 204, 89, 23);
			contentPanel.add(btnCancle);
		}

		JLabel lblNewLabel = new JLabel("Host");
		lblNewLabel.setBounds(23, 121, 46, 14);
		contentPanel.add(lblNewLabel);

		textFieldHost = new JTextField();
		textFieldHost.setBounds(121, 118, 208, 20);
		contentPanel.add(textFieldHost);
		textFieldHost.setColumns(10);

		JLabel lblPort = new JLabel("Port");
		lblPort.setBounds(23, 153, 46, 14);
		contentPanel.add(lblPort);

		textFieldPort = new JTextField();
		textFieldPort.setBounds(121, 150, 208, 20);
		contentPanel.add(textFieldPort);
		textFieldPort.setColumns(10);

		textFieldMailId.setText(props.getProperty("Username"));
		textFieldPassword.setText(props.getProperty("Password"));
		textFieldHost.setText(props.getProperty("Host"));
		textFieldPort.setText(props.getProperty("Port"));

	}

}
