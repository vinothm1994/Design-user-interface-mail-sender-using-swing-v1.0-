import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollBar;

public class Mailwindow extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textFieldTomail;
	private JTextField textFieldSubject;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Mailwindow dialog = new Mailwindow();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Mailwindow() {
		setTitle("Email sender");

		Properties props = new Properties();
		File file = new File("C:/Windows/Temp/mail.igx");

		setBounds(100, 100, 399, 468);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JLabel lblSentmailid = new JLabel("To");
		lblSentmailid.setBounds(10, 41, 72, 14);
		contentPanel.add(lblSentmailid);

		JLabel lblSubject = new JLabel("subject");
		lblSubject.setBounds(10, 77, 46, 14);
		contentPanel.add(lblSubject);

		JLabel lblBody = new JLabel("body");
		lblBody.setBounds(10, 120, 46, 14);
		contentPanel.add(lblBody);

		textFieldTomail = new JTextField();
		textFieldTomail.setBounds(81, 38, 250, 20);
		contentPanel.add(textFieldTomail);
		textFieldTomail.setColumns(10);

		textFieldSubject = new JTextField();
		textFieldSubject.setBounds(81, 74, 250, 20);
		contentPanel.add(textFieldSubject);
		textFieldSubject.setColumns(10);

		JTextArea textAreaBody = new JTextArea();
		textAreaBody.setBounds(81, 110, 250, 180);
		contentPanel.add(textAreaBody);

		JButton btnNewButton = new JButton("setting");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (file.exists() == false) {
					try {
						props.load(new FileReader(file));
					} catch (IOException e1) {
						e1.printStackTrace();
					}

					props.setProperty("Host", "smtp.gmail.com");
					props.setProperty("Port", "587");
					props.setProperty("Username", "@gmail.com");
					props.setProperty("Password", "XXXXXXXXX");
					JOptionPane.showMessageDialog(Mailwindow.this, "Setting txt file create");

					try {
						props.store(new FileWriter(file), "");
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
				Setting call2;

				try {
					call2 = new Setting();
					call2.setVisible(true);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				dispose();

			}
		});

		btnNewButton.setBounds(0, 0, 82, 20);
		contentPanel.add(btnNewButton);

		JButton btnSent = new JButton("sent");
		btnSent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String Tomail = textFieldTomail.getText();
				String subject = textFieldSubject.getText();
				String Body = textAreaBody.getText();

				try {
					boolean check = Mailmanager.sent(Tomail, subject, Body);
					if (check == true) {
						JOptionPane.showMessageDialog(Mailwindow.this, "Your mail is sent");

					} else {
						JOptionPane.showMessageDialog(Mailwindow.this, "Your mail is  not sent");

					}

				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		btnSent.setBounds(10, 378, 89, 23);
		contentPanel.add(btnSent);

		JButton btnCancle = new JButton("cancel");
		btnCancle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnCancle.setBounds(284, 378, 89, 23);
		contentPanel.add(btnCancle);

		JScrollBar scrollBar = new JScrollBar();
		scrollBar.setBounds(331, 110, 17, 180);
		contentPanel.add(scrollBar);

		JButton btnClean = new JButton("clean");
		btnClean.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				textFieldSubject.setText("");
				textFieldTomail.setText("");
				textAreaBody.setText("");

			}
		});
		btnClean.setBounds(157, 378, 89, 23);
		contentPanel.add(btnClean);
	}
}


